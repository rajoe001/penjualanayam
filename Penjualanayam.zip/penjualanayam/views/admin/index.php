<div class="container konten">
	<?php include'adminMenu.php';?>
	<div class="col-md-8">
		<h2>Selamat Datang <?php echo $namaAdmin;?></h2>
	</div>
</div>
