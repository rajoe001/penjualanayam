	<div class="col-md-4">
		<h3>Admin Session</h3>
		<a href="<?php echo URL;?>/admin/databarang">Data Barang</a><br />
		<a href="<?php echo URL;?>/admin/datauser">Data Pelanggan</a><br />
		<a href="<?php echo URL;?>/admin/transaksi">Transaksi</a><br />
		<a href="<?php echo URL;?>/admin/laporan">Laporan Penjualan</a><br /><br />
	</div>
