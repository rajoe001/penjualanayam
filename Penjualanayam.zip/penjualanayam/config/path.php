<?php
define("URL","http://".$_SERVER['SERVER_NAME']."/penjualanayam");
define("SITENAME","Penjualan Ayam");