<?php

return [
		"css"=>[
			URL."/vendor/bootstrap/css/bootstrap.min.css",
			URL."/vendor/font-awesome/css/font-awesome.min.css",
		],
		"js"=>[
			URL."/vendor/jquery/jquery.js",
			URL."/vendor/bootstrap/js/bootstrap.min.js",
			URL."/vendor/jquery/datatable.js",
			URL."/vendor/jquery/datatable.bootstrap.min.js",
		]
];