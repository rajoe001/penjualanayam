<?php
namespace models;
use libs\Model;

class Sample_Model extends Model {
	
	static $table = "sample";
	static $lbl = ["sample_id","sample_name","sample_description","sample_date"];
	
	
}